# vikcraft-pdf-editor

PDF viewer + annotation editor (PDF.js + Fabric.js + jsPDF). Ships vanilla ESM core and a React wrapper.

## Install

```bash
npm i vikcraft-pdf-editor fabric jspdf pdfjs-dist
# if you use React:
npm i react react-dom
```

### Configure PDF.js worker (Vite example)

```ts
// main.tsx or entry
import { configurePdfJs } from 'vikcraft-pdf-editor';
import workerSrc from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
configurePdfJs(workerSrc);
```

## Vanilla usage

Include Font Awesome in your HTML for toolbar icons:
```html
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
```

```ts
import { VikCraftPDFEditor } from 'vikcraft-pdf-editor';
import 'vikcraft-pdf-editor/style.css';

const editor = new VikCraftPDFEditor('container-id', {
  pdfPath: '/sample.pdf',
  currentUser: 'vik',
  ui: { enableCommentsPanel: true },
  permissions: { allowEdit: true, allowDelete: true },
  toolbar: {
    theme: 'light',
    actions: ['themeToggle'],
    navigation: ['prev','pageInput','next'],
    zoom: ['zoomOut','zoomIn','fitWidth'],
    drawing: [
      { tool: 'select' }, { tool: 'pan' },
      { tool: 'rect', promptForComment: true },
      { tool: 'ellipse', promptForComment: true },
      { tool: 'freehand' }, { tool: 'highlighter' }
    ],
    strokeSizes: [{label:'S',size:2},{label:'M',size:6},{label:'L',size:12}],
    colors: { palette: ['#E53935','#1E88E5','#43A047','#FFB300'], enablePicker: true },
    export: { asPDF: true }
  }
});
```

## React usage

```tsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import Editor from 'vikcraft-pdf-editor/react';
import 'vikcraft-pdf-editor/style.css';
import { configurePdfJs } from 'vikcraft-pdf-editor';
import workerSrc from 'pdfjs-dist/build/pdf.worker.min.mjs?url';

configurePdfJs(workerSrc);

ReactDOM.createRoot(document.getElementById('root')!).render(
  <Editor options={{
    pdfPath: '/sample.pdf',
    currentUser: 'vik',
    ui: { enableCommentsPanel: true },
    permissions: { allowEdit: true, allowDelete: true },
    toolbar: { /* same as above */ }
  }}/>
);
```

## Notes

- This package does **not** bundle `fabric`, `jspdf`, or `pdfjs-dist`; they are peer dependencies.
- Consumers must call `configurePdfJs(workerSrc)` with a valid worker URL (varies by bundler).
- Include Font Awesome CSS for toolbar icons.
