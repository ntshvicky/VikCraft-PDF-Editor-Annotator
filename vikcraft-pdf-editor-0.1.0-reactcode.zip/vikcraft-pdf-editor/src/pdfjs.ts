import * as pdfjsLib from 'pdfjs-dist';

/**
 * Call this once in your app to set PDF.js worker path.
 * Example (Vite):
 *   import worker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
 *   configurePdfJs(worker);
 */
export function configurePdfJs(workerSrc: string) {
  (pdfjsLib as any).GlobalWorkerOptions.workerSrc = workerSrc;
}

export { pdfjsLib };
