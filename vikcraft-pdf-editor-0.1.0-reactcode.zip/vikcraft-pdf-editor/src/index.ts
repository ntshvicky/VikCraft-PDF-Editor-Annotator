export { default as VikCraftPDFEditor } from './core/VikCraftPDFEditor';
export { configurePdfJs } from './pdfjs';

import './core/style.css';
