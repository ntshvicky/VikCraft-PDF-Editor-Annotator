import React, { useEffect, useRef, useId, useImperativeHandle, forwardRef } from 'react';
import { VikCraftPDFEditor } from './index';

export type Tool = 'select'|'pan'|'rect'|'ellipse'|'freehand'|'highlighter';

export interface VikCraftAnnotation {
  id: string|number;
  page: number;
  user: string;
  createdAt: string;
  comment?: string;
  fabric_json: any;
}

export interface VikCraftOptions {
  pdfPath: string;
  initialData?: VikCraftAnnotation[];
  currentUser?: string;
  exportOffset?: { x: number; y: number };
  permissions?: { allowEdit?: boolean; allowDelete?: boolean };
  ui?: { enableCommentsPanel?: boolean };
  toolbar?: {
    theme?: 'light'|'dark';
    actions?: ('themeToggle')[];
    navigation?: ('prev'|'pageInput'|'next')[];
    zoom?: ('zoomOut'|'zoomIn'|'fitWidth')[];
    drawing?: { tool: Tool; promptForComment?: boolean }[];
    strokeSizes?: { label: string; size: number }[];
    colors?: { palette: string[]; enablePicker?: boolean };
    export?: { asPDF?: boolean };
  };
  api?: { load: string; create: string; update: string; delete: string; };
}

export interface VikCraftPDFEditorRef {
  instance(): any | null;
  renderPage(page: number): void;
  onPrevPage(): void;
  onNextPage(): void;
  onZoom(level: 'in'|'out'|'fit'): void;
  setActiveTool(tool: Tool): void;
  setStrokeWidth(size: number): void;
  setColor(hex: string): void;
  focusOnComment(id: string): void;
  setTheme(theme: 'light'|'dark'): void;
  toggleTheme(): void;
  downloadAnnotatedPdf(): void;
}

interface Props {
  options: VikCraftOptions;
  className?: string;
  style?: React.CSSProperties;
  onAnnotationCreated?(a: VikCraftAnnotation): void;
  onAnnotationUpdated?(a: VikCraftAnnotation): void;
  onAnnotationDeleted?(a: { id: string|number }): void;
  onAnnotationSelected?(a: VikCraftAnnotation): void;
  onAnnotationDeselected?(): void;
}

const EditorReact = forwardRef<VikCraftPDFEditorRef, Props>(
  ({ options, className, style, ...events }, ref) => {
    const containerId = useId().replace(/:/g, '_');
    const editorRef = useRef<any>(null);

    useEffect(() => {
      const inst = new (VikCraftPDFEditor as any)(containerId, options);
      editorRef.current = inst;

      if (inst?.on) {
        if (events.onAnnotationCreated)   inst.on('annotation:created',  events.onAnnotationCreated);
        if (events.onAnnotationUpdated)   inst.on('annotation:updated',  events.onAnnotationUpdated);
        if (events.onAnnotationDeleted)   inst.on('annotation:deleted',  events.onAnnotationDeleted);
        if (events.onAnnotationSelected)  inst.on('annotation:selected', events.onAnnotationSelected);
        if (events.onAnnotationDeselected)inst.on('annotation:deselected', events.onAnnotationDeselected);
      }

      return () => {
        try { inst?.fabricCanvas?.dispose?.(); } catch {}
        editorRef.current = null;
      };
    }, [options]);

    useImperativeHandle(ref, () => ({
      instance:             ()    => editorRef.current,
      renderPage:           (n)   => editorRef.current?.renderPage?.(n),
      onPrevPage:           ()    => editorRef.current?.onPrevPage?.(),
      onNextPage:           ()    => editorRef.current?.onNextPage?.(),
      onZoom:               (lv)  => editorRef.current?.onZoom?.(lv),
      setActiveTool:        (t)   => editorRef.current?.setActiveTool?.(t),
      setStrokeWidth:       (s)   => editorRef.current?.setStrokeWidth?.(s),
      setColor:             (hex) => editorRef.current?.setColor?.(hex),
      focusOnComment:       (id)  => editorRef.current?.focusOnComment?.(id),
      setTheme:             (th)  => editorRef.current?.setTheme?.(th),
      toggleTheme:          ()    => editorRef.current?.toggleTheme?.(),
      downloadAnnotatedPdf: ()    => editorRef.current?.downloadAnnotatedPdf?.(),
    }), []);

    return <div id={containerId} className={className} style={style} />;
  }
);

EditorReact.displayName = 'VikCraftPDFEditorReact';
export default EditorReact;
