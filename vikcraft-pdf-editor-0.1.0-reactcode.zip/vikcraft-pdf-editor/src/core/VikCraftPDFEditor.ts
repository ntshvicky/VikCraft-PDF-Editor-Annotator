// Ported core editor (TypeScript)
import { fabric } from 'fabric';
import { jsPDF } from 'jspdf';
import { pdfjsLib } from '../pdfjs';

type Tool = 'select'|'pan'|'rect'|'ellipse'|'freehand'|'highlighter';

type ApiEndpoints = { load: string; create: string; update: string; delete: string; };

type ToolbarOptions = {
  theme?: 'light'|'dark';
  actions?: ('themeToggle')[];
  navigation?: ('prev'|'pageInput'|'next')[];
  zoom?: ('zoomOut'|'zoomIn'|'fitWidth')[];
  drawing?: { tool: Tool; promptForComment?: boolean }[];
  strokeSizes?: { label: string; size: number }[];
  colors?: { palette: string[]; enablePicker?: boolean };
  export?: { asPDF?: boolean };
};

type Options = {
  pdfPath: string;
  initialData?: any[];
  currentUser?: string;
  exportOffset?: { x: number; y: number };
  permissions?: { allowEdit?: boolean; allowDelete?: boolean };
  ui?: { enableCommentsPanel?: boolean };
  toolbar?: ToolbarOptions;
  api?: ApiEndpoints;
};

class ApiService {
  endpoints: ApiEndpoints;
  constructor(endpoints: ApiEndpoints) { this.endpoints = endpoints; }
  async _request(url: string, method: string, body: any = null) {
    const options: RequestInit = { method, headers: { 'Content-Type': 'application/json' } };
    if (body) options.body = JSON.stringify(body);
    const response = await fetch(url, options);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    if (method === 'DELETE') return { ok: true };
    return await response.json();
  }
  load() { return this._request(this.endpoints.load, 'GET'); }
  create(data: any) { return this._request(this.endpoints.create, 'POST', data); }
  update(data: any) { return this._request(this.endpoints.update + data.id + '/', 'PUT', data); }
  delete(id: string | number) { return this._request(this.endpoints.delete + id + '/', 'DELETE'); }
}

export default class VikCraftPDFEditor {
  container: HTMLElement;
  options: Options;
  _eventListeners: Record<string, Function[]> = {};
  pdfPath: string;
  api: ApiService | null;

  pdfDoc: any;
  currentPage = 1;
  zoomScale = 1.5;

  fabricCanvas: fabric.Canvas | null = null;
  isDrawing = false;
  activeShape: any = null;

  allAnnotations: any[] = [];
  activeTool: Tool = 'select';
  activeColor = '#E53935';
  activeStrokeWidth: number;
  highlighterOpacity = '80';
  editingAnnotation: any = null;

  isPanning = false;
  lastPanPoint = { x: 0, y: 0 };

  viewerMain!: HTMLElement;
  toolbar!: HTMLElement;
  loader!: HTMLElement;
  commentModal!: HTMLElement;
  commentText!: HTMLTextAreaElement;
  contextMenu!: HTMLElement;
  pdfCanvas!: HTMLCanvasElement;
  pdfCtx!: CanvasRenderingContext2D;
  tooltip!: HTMLDivElement;
  commentsList!: HTMLElement;
  pageInput!: HTMLInputElement;
  pageCountDisplay!: HTMLElement;

  constructor(containerId: string, options: Options) {
    const el = document.getElementById(containerId);
    if (!el) throw new Error("Editor container not found!");
    this.container = el;
    this.options = options;
    this.pdfPath = options.pdfPath;
    this.api = options.api ? new ApiService(options.api) : null;
    this.activeStrokeWidth = options.toolbar?.strokeSizes?.[1]?.size || 6;

    this._createDOM();
    void this.init();
  }

  _createDOM() {
    const hasCommentsPanel = this.options.ui?.enableCommentsPanel !== false;
    this.container.innerHTML = `
      <div class="vc-pdf-main-grid ${hasCommentsPanel ? '' : 'single-column'}">
        <div class="vc-pdf-viewer-wrapper">
          <div id="vc-pdf-toolbar"></div>
          <div id="vc-pdf-viewer-main">
            <canvas id="vc-pdf-pdf-canvas"></canvas>
            <canvas id="vc-pdf-annotation-canvas"></canvas>
            <div id="vc-pdf-context-menu"></div> 
          </div>
        </div>
        ${hasCommentsPanel ? `
        <div class="vc-pdf-comments-panel">
          <div class="vc-pdf-comments-header">All Comments</div>
          <div id="vc-pdf-comments-list"></div>
        </div>` : ''}
      </div>
      <div id="vc-pdf-comment-modal"></div>
      <div id="vc-pdf-loader-overlay"></div>
      <div id="vc-pdf-tooltip"></div>
    `;
    this.container.querySelector('#vc-pdf-comment-modal')!.innerHTML =
      `<div class="vc-pdf-modal-content"><h4 id="vc-pdf-comment-modal-title">Add Comment</h4><textarea id="vc-pdf-comment-text" rows="4"></textarea><div class="vc-pdf-modal-buttons"><button id="vc-pdf-comment-cancel">Cancel</button><button id="vc-pdf-comment-save">Save</button></div></div>`;
    this.container.querySelector('#vc-pdf-context-menu')!.innerHTML =
      `<button data-action="edit" title="Edit Comment"><i class="fas fa-pencil-alt"></i></button><button data-action="delete" title="Delete"><i class="fas fa-trash"></i></button>`;
    this.container.querySelector('#vc-pdf-loader-overlay')!.innerHTML =
      `<div class="vc-pdf-loader-content"><div class="vc-pdf-spinner"></div><p id="vc-pdf-loader-message">Please wait...</p></div>`;
  }

  async init() {
    this.viewerMain = this.container.querySelector('#vc-pdf-viewer-main') as HTMLElement;
    this.toolbar = this.container.querySelector('#vc-pdf-toolbar') as HTMLElement;
    this.loader = this.container.querySelector('#vc-pdf-loader-overlay') as HTMLElement;
    this.commentModal = this.container.querySelector('#vc-pdf-comment-modal') as HTMLElement;
    this.commentText = this.container.querySelector('#vc-pdf-comment-text') as HTMLTextAreaElement;
    this.contextMenu = this.container.querySelector('#vc-pdf-context-menu') as HTMLElement;
    this.pdfCanvas = this.container.querySelector('#vc-pdf-pdf-canvas') as HTMLCanvasElement;
    const ctx = this.pdfCanvas.getContext('2d');
    if (!ctx) throw new Error('2D context not available');
    this.pdfCtx = ctx;
    this.tooltip = this.container.querySelector('#vc-pdf-tooltip') as HTMLDivElement;
    this.commentsList = this.container.querySelector('#vc-pdf-comments-list') as HTMLElement;

    this.setTheme(this.options.toolbar?.theme || 'light');
    this._buildToolbar();
    this.pageInput = this.container.querySelector('#vc-pdf-page-num-input') as HTMLInputElement;
    this.pageCountDisplay = this.container.querySelector('#vc-pdf-page-count') as HTMLElement;

    this.fabricCanvas = new fabric.Canvas('vc-pdf-annotation-canvas');
    this.setupEventListeners();
    await this.loadDocument();
  }

  _buildToolbar() {
    const tb = this.options.toolbar; if (!tb) return;
    this.toolbar.innerHTML = '';
    const toolMap: Record<string, string> = {
      themeToggle: `<button id="vc-pdf-theme-toggle" title="Toggle Theme"><i class="fas fa-moon"></i></button>`,
      pan: `<button data-tool="pan" title="Pan Tool"><i class="fas fa-hand-paper"></i></button>`,
      prev: `<button id="vc-pdf-prev-page" title="Previous Page"><i class="fas fa-arrow-left"></i></button>`,
      next: `<button id="vc-pdf-next-page" title="Next Page"><i class="fas fa-arrow-right"></i></button>`,
      pageInput: `<input type="number" id="vc-pdf-page-num-input" value="1" min="1"><span class="vc-pdf-page-indicator">/ <span id="vc-pdf-page-count">--</span></span>`,
      zoomIn: `<button id="vc-pdf-zoom-in" title="Zoom In"><i class="fas fa-search-plus"></i></button>`,
      zoomOut: `<button id="vc-pdf-zoom-out" title="Zoom Out"><i class="fas fa-search-minus"></i></button>`,
      fitWidth: `<button id="vc-pdf-fit-width" title="Fit to Width"><i class="fas fa-arrows-alt-h"></i></button>`,
      select: `<button data-tool="select" title="Select"><i class="fas fa-mouse-pointer"></i></button>`,
      rect: `<button data-tool="rect" title="Rectangle"><i class="far fa-square"></i></button>`,
      ellipse: `<button data-tool="ellipse" title="Circle"><i class="far fa-circle"></i></button>`,
      freehand: `<button data-tool="freehand" title="Pen"><i class="fas fa-pencil-alt"></i></button>`,
      highlighter: `<button data-tool="highlighter" title="Highlighter"><i class="fas fa-highlighter"></i></button>`,
      asPDF: `<button id="vc-pdf-export-pdf" title="Download Annotated PDF"><i class="fas fa-file-pdf"></i></button>`
    };
    const createGroup = (tools: any[], id = '') => {
      const group = document.createElement('div');
      group.className = 'vc-pdf-tool-group'; if (id) group.id = `vc-pdf-${id}`;
      tools.forEach(tool => {
        if (typeof tool === 'object') { group.innerHTML += toolMap[tool.tool] || ''; } 
        else { group.innerHTML += toolMap[tool] || ''; }
      });
      return group;
    };
    const groups: HTMLElement[] = [];
    if (tb.actions) groups.push(createGroup(tb.actions));
    if (tb.navigation) groups.push(createGroup(tb.navigation));
    if (tb.zoom) groups.push(createGroup(tb.zoom));
    if (tb.drawing) groups.push(createGroup(tb.drawing, 'drawing-tools'));
    if (tb.strokeSizes && tb.strokeSizes.length > 0) {
      const sizeGroup = document.createElement('div');
      sizeGroup.className = 'vc-pdf-tool-group'; sizeGroup.id = 'vc-pdf-size-selector';
      tb.strokeSizes.forEach(stroke => { sizeGroup.innerHTML += `<button data-size="${stroke.size}" title="${stroke.label} Size">${stroke.label}</button>`; });
      groups.push(sizeGroup);
    }
    if (tb.colors && tb.colors.palette) {
      const colorGroup = document.createElement('div');
      colorGroup.className = 'vc-pdf-tool-group'; colorGroup.id = 'vc-pdf-color-palette';
      tb.colors.palette.forEach(color => { colorGroup.innerHTML += `<div class="vc-pdf-color-box" data-color="${color}" style="background: ${color};"></div>`; });
      if (tb.colors.enablePicker) { colorGroup.innerHTML += `<input type="color" id="vc-pdf-color-picker" value="${this.activeColor}" title="Custom Color">`; }
      groups.push(colorGroup);
    }
    if (tb.export && tb.export.asPDF) groups.push(createGroup(['asPDF']));
    groups.forEach((group, index) => {
      this.toolbar.appendChild(group);
      if (index < groups.length - 1 && group.hasChildNodes()) {
        const spacer = document.createElement('div'); spacer.className = 'vc-pdf-spacer'; this.toolbar.appendChild(spacer);
      }
    });
  }

  setupEventListeners() {
    if (this.toolbar) {
      this.toolbar.addEventListener('click', (e) => {
        const button = (e.target as HTMLElement).closest('button') as HTMLButtonElement | null;
        if (button) {
          const tool = button.dataset.tool as Tool | undefined; const id = button.id;
          if (tool) this.setActiveTool(tool);
          else if (id === 'vc-pdf-theme-toggle') this.toggleTheme();
          else if (id === 'vc-pdf-prev-page') this.onPrevPage(); else if (id === 'vc-pdf-next-page') this.onNextPage();
          else if (id === 'vc-pdf-zoom-in') this.onZoom('in'); else if (id === 'vc-pdf-zoom-out') this.onZoom('out');
          else if (id === 'vc-pdf-fit-width') this.onZoom('fit'); else if (id === 'vc-pdf-export-pdf') this.downloadAnnotatedPdf();
        }
        const colorBox = (e.target as HTMLElement).closest('.vc-pdf-color-box') as HTMLElement | null; if (colorBox) this.setColor(colorBox.dataset.color!);
        const sizeButton = (e.target as HTMLElement).closest('#vc-pdf-size-selector button') as HTMLButtonElement | null; if (sizeButton) this.setStrokeWidth(parseInt(sizeButton.dataset.size!, 10));
      });
    }
    if (this.pageInput) this.pageInput.addEventListener('change', this.goToPage.bind(this));
    const colorPicker = this.container.querySelector('#vc-pdf-color-picker') as HTMLInputElement | null;
    if (colorPicker) colorPicker.addEventListener('input', (e: any) => this.setColor(e.target.value));
    if (this.commentModal) {
      this.commentModal.querySelector('#vc-pdf-comment-save')!.addEventListener('click', this.saveComment.bind(this));
      this.commentModal.querySelector('#vc-pdf-comment-cancel')!.addEventListener('click', this.cancelComment.bind(this));
    }
    if (this.contextMenu) {
      this.contextMenu.addEventListener('click', (e) => {
        const action = (e.target as HTMLElement).closest('button')?.getAttribute('data-action');
        if (action === 'edit') this._handleEdit(); else if (action === 'delete') this._handleDelete();
      });
    }
    if (this.commentsList) {
      this.commentsList.addEventListener('click', (e) => {
        const card = (e.target as HTMLElement).closest('.vc-pdf-comment-card') as HTMLElement | null;
        if (card && (card as any).dataset.id) this.focusOnComment((card as any).dataset.id);
      });
    }
    if (this.viewerMain) {
      this.viewerMain.addEventListener('mousedown', (e) => {
        if (this.activeTool === 'pan') {
          this.isPanning = true; this.lastPanPoint = { x: (e as MouseEvent).clientX, y: (e as MouseEvent).clientY };
          this.viewerMain.classList.add('is-panning');
        }
      });
      this.viewerMain.addEventListener('mousemove', (e) => {
        if (this.isPanning) {
          const dx = (e as MouseEvent).clientX - this.lastPanPoint.x; const dy = (e as MouseEvent).clientY - this.lastPanPoint.y;
          this.viewerMain.scrollLeft -= dx; this.viewerMain.scrollTop -= dy;
          this.lastPanPoint = { x: (e as MouseEvent).clientX, y: (e as MouseEvent).clientY };
        }
      });
      const stopPan = () => { this.isPanning = false; this.viewerMain.classList.remove('is-panning'); };
      this.viewerMain.addEventListener('mouseup', stopPan);
      this.viewerMain.addEventListener('mouseleave', stopPan);
      this.viewerMain.addEventListener('wheel', (e: any) => {
        if (e.ctrlKey) { e.preventDefault(); const delta = e.deltaY > 0 ? 'out' : 'in'; this.onZoom(delta as any); }
      }, { passive: false });
    }
    if (this.fabricCanvas) {
      this.fabricCanvas.on({
        'mouse:down': this.handleMouseDown.bind(this),
        'mouse:move': (e) => { this.handleMouseMove(e as any); this._handleTooltipMove(e as any); },
        'mouse:up': this.handleMouseUp.bind(this), 'path:created': this.handlePathCreated.bind(this),
        'selection:created': (e: any) => { this._showContextualMenu(e.selected[0]); this._highlightCommentCard(e.selected[0].id); this._fire('annotation:selected', this.allAnnotations.find(a => a.id === e.selected[0].id)); },
        'selection:updated': (e: any) => { this._showContextualMenu(e.selected[0]); this._highlightCommentCard(e.selected[0].id); this._fire('annotation:selected', this.allAnnotations.find(a => a.id === e.selected[0].id)); },
        'selection:cleared': () => { this._hideContextualMenu(); this._highlightCommentCard(null as any); this._fire('annotation:deselected', undefined); },
        'mouse:over': (e) => this._showTooltip(e as any), 'mouse:out': this._hideTooltip.bind(this),
        'object:modified': this._handleObjectModified.bind(this),
      });
    }
  }

  on(eventName: string, callback: Function) {
    if (!this._eventListeners[eventName]) { this._eventListeners[eventName] = []; }
    this._eventListeners[eventName].push(callback);
  }
  _fire(eventName: string, data: any) {
    if (this._eventListeners[eventName]) {
      this._eventListeners[eventName].forEach(callback => { try { callback(data); } catch (e) { console.error(`Error in '${eventName}' event listener:`, e); } });
    }
  }

  async addAnnotation(fabricObject: any) {
    if (!fabricObject) return;
    const toolConfig = this.options.toolbar?.drawing?.find(d => d.tool === this.activeTool);
    const annotationId = `temp-${Date.now()}`;
    fabricObject.set('id', annotationId);
    const newAnnotation = {
      id: annotationId, page: this.currentPage, user: this.options.currentUser || 'Guest',
      createdAt: new Date().toISOString(), fabric_json: fabricObject.toJSON(['id']), comment: '',
    };
    this._fire('annotation:created', newAnnotation);
    if (toolConfig?.promptForComment) {
      this._promptForComment(newAnnotation, true);
    } else if (this.api) {
      try {
        const savedAnnotation = await this.api.create(newAnnotation);
        newAnnotation.id = savedAnnotation.id;
        fabricObject.set('id', savedAnnotation.id);
        this.allAnnotations.push(savedAnnotation);
      } catch (error) { this.fabricCanvas?.remove(fabricObject); }
    } else {
      this.allAnnotations.push(newAnnotation);
    }
  }

  async loadDocument() {
    try {
      this.loader.style.display = 'flex';
      if (this.options.initialData) { this.allAnnotations = this.options.initialData; } 
      else if (this.api) { this.allAnnotations = await this.api.load(); }
      if (this.options.ui?.enableCommentsPanel !== false) { this._renderCommentsList(); }
      const pdfTask = pdfjsLib.getDocument(this.pdfPath as any);
      this.pdfDoc = await (pdfTask as any).promise;
      if (this.pageCountDisplay) this.pageCountDisplay.textContent = this.pdfDoc.numPages;
      if (this.pageInput) this.pageInput.max = this.pdfDoc.numPages;
      this.setActiveTool('select');
      this.setColor(this.activeColor);
      this.setStrokeWidth(this.activeStrokeWidth);
      await this.renderPage(1);
    } catch (error) { console.error("Error loading document:", error); } 
    finally { this.loader.style.display = 'none'; }
  }
  _renderCommentsList() {
    if (!this.commentsList) return;
    this.commentsList.innerHTML = '';
    const comments = this.allAnnotations.filter(a => a.comment);
    if (comments.length === 0) {
      this.commentsList.innerHTML = `<div style="text-align:center; padding: 20px; color: var(--vc-pdf-text-secondary);">No comments yet.</div>`;
      return;
    }
    comments.forEach(anno => {
      const card = document.createElement('div');
      card.className = 'vc-pdf-comment-card';
      (card as any).dataset.id = anno.id;
      card.innerHTML = `<div class="vc-pdf-comment-card-header"><span class="vc-pdf-comment-user">${anno.user || 'Guest'}</span><span class="vc-pdf-comment-page">Page ${anno.page}</span></div><div class="vc-pdf-comment-body">${anno.comment}</div>`;
      this.commentsList.appendChild(card);
    });
  }
  _highlightCommentCard(annotationId: string | null) {
    if (!this.commentsList) return;
    this.commentsList.querySelectorAll('.vc-pdf-comment-card').forEach(card => {
      (card as HTMLElement).classList.toggle('active', (card as any).dataset.id === annotationId);
    });
    if (annotationId) {
      const activeCard = this.commentsList.querySelector(`[data-id="${annotationId}"]`) as HTMLElement | null;
      if (activeCard) activeCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }
  _promptForComment(annotation: any, isCreating = false) {
    this.editingAnnotation = annotation;
    (this.container.querySelector('#vc-pdf-comment-modal-title') as HTMLElement).textContent = isCreating ? 'Add Comment' : 'Edit Comment';
    this.commentText.value = annotation.comment || '';
    this.commentModal.classList.add('visible');
    this.commentText.focus();
  }
  async saveComment() {
    if (!this.editingAnnotation) return;
    this.editingAnnotation.comment = this.commentText.value.trim();
    let savedAnnotation = this.editingAnnotation;
    if (this.api) {
      const isCreating = this.editingAnnotation.id.toString().startsWith('temp-');
      try {
        savedAnnotation = isCreating ? await this.api.create(this.editingAnnotation) : await this.api.update(this.editingAnnotation);
        const fabricObject = this.fabricCanvas?.getObjects().find((o: any) => o.id === this.editingAnnotation.id) as any;
        if (fabricObject) fabricObject.set('id', savedAnnotation.id);
        if (isCreating) { this.allAnnotations.push(savedAnnotation); } 
        else {
          const index = this.allAnnotations.findIndex(a => a.id === savedAnnotation.id);
          if (index !== -1) this.allAnnotations[index] = savedAnnotation;
        }
      } catch (error) {
        if(isCreating) {
          const fabricObject = this.fabricCanvas?.getObjects().find((o: any) => o.id === this.editingAnnotation.id) as any;
          if(fabricObject) this.fabricCanvas?.remove(fabricObject);
        }
      }
    }
    this.cancelComment();
    this._renderCommentsList();
    this._fire('annotation:updated', savedAnnotation);
  }
  cancelComment() {
    this.commentModal.classList.remove('visible');
    this.commentText.value = '';
    if (this.editingAnnotation && this.editingAnnotation.id.toString().startsWith('temp-') && !this.editingAnnotation.comment) {
         const fabricObject = this.fabricCanvas?.getObjects().find((o: any) => o.id === this.editingAnnotation.id) as any;
         if(fabricObject) this.fabricCanvas?.remove(fabricObject);
    }
    this.editingAnnotation = null;
  }
  _showContextualMenu(fabricObject: any) {
    this._hideTooltip();
    const annotation = this.allAnnotations.find(a => a.id === fabricObject.id);
    if (!annotation) return;
    const menu = this.contextMenu; menu.innerHTML = '';
    const canEdit = !!(this.options.permissions?.allowEdit && annotation.user === this.options.currentUser);
    const canDelete = !!(this.options.permissions?.allowDelete && annotation.user === this.options.currentUser);
    if (canEdit) { menu.innerHTML += `<button data-action="edit" title="Edit Comment"><i class="fas fa-pencil-alt"></i></button>`; }
    if (canDelete) { menu.innerHTML += `<button data-action="delete" title="Delete"><i class="fas fa-trash"></i></button>`; }
    if (!canEdit && !canDelete) return;
    const pos = fabricObject.getCoords(true, true)[1];
    menu.style.left = `${pos.x + 10}px`; menu.style.top = `${pos.y - 10}px`;
    menu.classList.add('visible');
  }
  _hideContextualMenu() { this.contextMenu.classList.remove('visible'); }
  _handleEdit() {
    const activeObject = this.fabricCanvas?.getActiveObject() as any;
    if (!activeObject) return;
    const annotation = this.allAnnotations.find(a => a.id === activeObject.id);
    const canEdit = !!(this.options.permissions?.allowEdit && annotation?.user === this.options.currentUser);
    if (annotation && canEdit) { this._promptForComment(annotation, false); }
    this._hideContextualMenu();
  }
  async _handleDelete() {
    const activeObject = this.fabricCanvas?.getActiveObject() as any;
    if (!activeObject) return;
    const annotation = this.allAnnotations.find(a => a.id === activeObject.id);
    const canDelete = !!(this.options.permissions?.allowDelete && annotation?.user === this.options.currentUser);
    if (!annotation || !canDelete) { this._hideContextualMenu(); return; }
    if (window.confirm('Are you sure you want to delete this annotation?')) {
      const idToDelete = activeObject.id;
      if (this.api) {
        try {
          await this.api.delete(idToDelete);
          this.allAnnotations = this.allAnnotations.filter(a => a.id !== idToDelete);
          this.fabricCanvas?.remove(activeObject);
          this._fire('annotation:deleted', { id: idToDelete });
        } catch (error) { console.error("Failed to delete annotation:", error); }
      } else {
        this.allAnnotations = this.allAnnotations.filter(a => a.id !== idToDelete);
        this.fabricCanvas?.remove(activeObject);
        this._fire('annotation:deleted', { id: idToDelete });
      }
      this._renderCommentsList();
    }
    this._hideContextualMenu();
  }
  _showTooltip(e: any) {
    if (!e.target || this.contextMenu.classList.contains('visible')) return;
    const annotation = this.allAnnotations.find(a => a.id === (e.target as any).id);
    if (annotation && (annotation.comment || annotation.user)) {
      const date = annotation.createdAt ? new Date(annotation.createdAt).toLocaleString() : '';
      this.tooltip.innerHTML = `<div class="comment-user">${annotation.user || 'Guest'}</div><div class="comment-time">${date}</div><div class="comment-body">${annotation.comment || '<i>No comment</i>'}</div>`;
      this.tooltip.style.left = `${e.e.clientX + 15}px`;
      this.tooltip.style.top = `${e.e.clientY + 15}px`;
      this.tooltip.classList.add('visible');
    }
  }
  _hideTooltip() { this.tooltip.classList.remove('visible'); }
  _handleTooltipMove(e: any) {
    if (this.tooltip.classList.contains('visible')) {
      this.tooltip.style.left = `${e.e.clientX + 15}px`;
      this.tooltip.style.top = `${e.e.clientY + 15}px`;
    }
  }
  async focusOnComment(id: string) {
    const annotation = this.allAnnotations.find(a => a.id === id);
    if (!annotation) { console.warn(`Annotation with ID ${id} not found.`); return; }
    this._highlightCommentCard(id);
    if (this.currentPage !== annotation.page) { await this.renderPage(annotation.page); }
    const fabricObject = this.fabricCanvas?.getObjects().find((o: any) => o.id === id) as any;
    if (fabricObject) {
      this.fabricCanvas?.setActiveObject(fabricObject).renderAll();
      const objCenter = fabricObject.getCenterPoint();
      this.viewerMain.scrollTo({
        left: (objCenter.x * this.zoomScale) - (this.viewerMain.clientWidth / 2),
        top: (objCenter.y * this.zoomScale) - (this.viewerMain.clientHeight / 2),
        behavior: 'smooth'
      });
      const originalColor = fabricObject.stroke;
      fabricObject.set('stroke', '#0d6efd');
      this.fabricCanvas?.renderAll();
      setTimeout(() => {
        fabricObject.set('stroke', originalColor);
        this.fabricCanvas?.renderAll();
      }, 1000);
    }
  }
  setTheme(theme: 'light'|'dark') {
    (this.container as any).dataset.theme = theme;
    const icon = this.container.querySelector('#vc-pdf-theme-toggle i') as HTMLElement | null;
    if (icon) { icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon'; }
  }
  toggleTheme() {
    const newTheme = (this.container as any).dataset.theme === 'dark' ? 'light' : 'dark';
    this.setTheme(newTheme);
  }
  async renderPage(pageNum: number) {
    if (!this.pdfDoc) return;
    this.fabricCanvas?.clear(); this._hideContextualMenu();
    this.currentPage = pageNum; if(this.pageInput) this.pageInput.value = String(pageNum);
    const page = await this.pdfDoc.getPage(pageNum);
    const viewport = page.getViewport({ scale: this.zoomScale });
    this.pdfCanvas.height = viewport.height; this.pdfCanvas.width = viewport.width;
    this.fabricCanvas?.setDimensions({ width: viewport.width, height: viewport.height });
    this.fabricCanvas?.setZoom(this.zoomScale);
    await page.render({ canvasContext: this.pdfCtx, viewport }).promise;
    await this.loadAnnotationsForPage(pageNum);
  }
  loadAnnotationsForPage(pageNum: number) {
    return new Promise<void>(resolve => {
      const annotations = this.allAnnotations.filter(a => a.page === pageNum);
      if (annotations.length === 0) { resolve(); return; }
      const fabricObjects = annotations.map(a => {
        const fabricJson = typeof a.fabric_json === 'string' ? JSON.parse(a.fabric_json) : a.fabric_json;
        fabricJson.id = a.id;
        return fabricJson;
      });
      this.fabricCanvas?.loadFromJSON({ objects: fabricObjects }, () => {
        this.fabricCanvas?.getObjects().forEach((obj: any, index) => {
          if (!obj.id) obj.set('id', annotations[index].id);
          const annotation = annotations[index];
          const isOwner = annotation.user === this.options.currentUser;
          const canModify = !!(this.options.permissions?.allowEdit && isOwner);
          obj.set({
            selectable: this.activeTool === 'select',
            lockMovementX: !canModify, lockMovementY: !canModify,
            lockScalingX: !canModify, lockScalingY: !canModify,
            lockRotation: true, hasControls: canModify
          });
        });
        this.fabricCanvas?.renderAll();
        resolve();
      });
    });
  }
  setActiveTool(tool: Tool) {
    this.activeTool = tool;
    if (this.fabricCanvas) {
      this.fabricCanvas.isDrawingMode = tool === 'freehand';
      const isInteractive = tool !== 'pan';
      this.fabricCanvas.selection = isInteractive && tool === 'select';
      this.fabricCanvas.getObjects().forEach((obj: any) => {
        obj.set({ selectable: isInteractive && tool === 'select', evented: isInteractive });
      });
      this.viewerMain.classList.toggle('pan-mode', tool === 'pan');
      if (tool === 'freehand') {
        (this.fabricCanvas.freeDrawingBrush as any).width = this.activeStrokeWidth;
        (this.fabricCanvas.freeDrawingBrush as any).color = this.activeColor;
      }
      const drawingTools = this.container.querySelector('#vc-pdf-drawing-tools') as HTMLElement | null;
      if(drawingTools) {
        drawingTools.querySelectorAll('button').forEach(btn => {
          const toolConfig = this.options.toolbar?.drawing?.find(d => d.tool === (btn as any).dataset.tool);
          if(toolConfig) btn.classList.toggle('active', (toolConfig as any).tool === tool);
        });
      }
      if(tool !== 'select') this.fabricCanvas.discardActiveObject().renderAll();
      this._hideContextualMenu();
      (this.fabricCanvas as any).defaultCursor = tool === 'select' ? 'default' : 'crosshair';
    }
  }
  setStrokeWidth(size: number) {
    this.activeStrokeWidth = size;
    if (this.fabricCanvas?.isDrawingMode) {
      (this.fabricCanvas.freeDrawingBrush as any).width = size;
    }
    const sizeSelector = this.container.querySelector('#vc-pdf-size-selector') as HTMLElement | null;
    if(sizeSelector) {
      sizeSelector.querySelectorAll('button').forEach(btn => {
        btn.classList.toggle('active', parseInt((btn as HTMLElement).dataset.size!, 10) === size);
      });
    }
  }
  setColor(color: string) {
    this.activeColor = color;
    if (this.fabricCanvas?.isDrawingMode) {
         (this.fabricCanvas.freeDrawingBrush as any).color = color;
    }
    const colorPalette = this.container.querySelector('#vc-pdf-color-palette') as HTMLElement | null;
    if(colorPalette) {
      colorPalette.querySelectorAll('.vc-pdf-color-box').forEach(box => {
        (box as HTMLElement).classList.toggle('active', (box as HTMLElement).dataset.color!.toLowerCase() === color.toLowerCase());
      });
    }
  }
  handleMouseDown(o: any) {
    if (this.activeTool === 'pan' || this.fabricCanvas?.isDrawingMode || this.activeTool === 'select') return;
    this.isDrawing = true;
    const pointer = this.fabricCanvas!.getPointer(o.e);
    (this as any).drawingStartPos = { x: pointer.x, y: pointer.y };
    let shape: any;
    const options = { left: pointer.x, top: pointer.y, width: 0, height: 0, selectable: false, };
    if (this.activeTool === 'rect' || this.activeTool === 'ellipse') {
      const shapeOptions = { ...options, stroke: this.activeColor, strokeWidth: this.activeStrokeWidth, fill: 'transparent' };
      shape = this.activeTool === 'rect' ? new (fabric as any).Rect(shapeOptions) : new (fabric as any).Ellipse({ ...shapeOptions, rx: 0, ry: 0 });
    } else if (this.activeTool === 'highlighter') {
      shape = new (fabric as any).Rect({ ...options, fill: this.activeColor + this.highlighterOpacity, strokeWidth: 0 });
    }
    this.activeShape = shape;
    if (this.activeShape) this.fabricCanvas?.add(this.activeShape);
  }
  handleMouseMove(o: any) {
    if (!this.isDrawing || !this.activeShape) return;
    const pointer = this.fabricCanvas!.getPointer(o.e);
    const w = Math.abs((this as any).drawingStartPos.x - pointer.x);
    const h = Math.abs((this as any).drawingStartPos.y - pointer.y);
    this.activeShape.set({
      left: Math.min((this as any).drawingStartPos.x, pointer.x),
      top: Math.min((this as any).drawingStartPos.y, pointer.y),
      width: w, height: h,
    });
    if (this.activeShape.type === 'ellipse') this.activeShape.set({ rx: w/2, ry: h/2 });
    this.fabricCanvas!.renderAll();
  }
  handleMouseUp() {
    if (this.isDrawing) {
      this.addAnnotation(this.activeShape);
      this.isDrawing = false;
      this.activeShape = null;
    }
  }
  handlePathCreated(e: any) { this.addAnnotation(e.path); }
  async _handleObjectModified(e: any) {
    const modifiedObject = e.target;
    if (!modifiedObject || !modifiedObject.id) return;
    const annotation = this.allAnnotations.find(a => a.id === modifiedObject.id);
    if (annotation) {
      annotation.fabric_json = modifiedObject.toJSON(['id']);
      this._fire('annotation:updated', annotation);
      if (this.api) {
        try { await this.api.update(annotation); }
        catch (error) { console.error("Failed to save updated annotation:", error); }
      }
    }
  }
  async downloadAnnotatedPdf() {
    if (!this.pdfDoc) return;
    this.loader.style.display = 'flex';
    const newPdf = new jsPDF({ orientation: 'p', unit: 'pt' });
    const renderScale = 2.0;
    const offsetX = this.options.exportOffset?.x || 0;
    const offsetY = this.options.exportOffset?.y || 0;
    try {
      for (let i = 1; i <= this.pdfDoc.numPages; i++) {
        (this.container.querySelector('#vc-pdf-loader-message') as HTMLElement).textContent = `Processing page ${i} of ${this.pdfDoc.numPages}...`;
        const page = await this.pdfDoc.getPage(i);
        const viewport = page.getViewport({ scale: renderScale });
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = viewport.width;
        tempCanvas.height = viewport.height;
        const tempCtx = tempCanvas.getContext('2d')!;
        await page.render({ canvasContext: tempCtx, viewport }).promise;
        const annotations = this.allAnnotations.filter(a => a.page === i);
        if (annotations.length > 0) {
          const tempFabric = new (fabric as any).StaticCanvas(null, { width: viewport.width, height: viewport.height });
          const fabricObjects = annotations.map(a => {
            const json = typeof a.fabric_json === 'string' ? JSON.parse(a.fabric_json) : a.fabric_json;
            json.left += offsetX;
            json.top += offsetY;
            return json;
          });
          await new Promise<void>(resolve => (tempFabric as any).loadFromJSON({ objects: fabricObjects }, resolve));
          const shapes = [...(tempFabric as any).getObjects()];
          for (const shape of shapes) {
            const annotation = annotations.find(a => a.id === shape.id);
            if (annotation && annotation.comment) {
              shape.scaleX *= renderScale;
              shape.scaleY *= renderScale;
              const bounds = shape.getBoundingRect();
              const text = new (fabric as any).Textbox(annotation.comment, {
                width: bounds.width < (150 * renderScale) ? (150 * renderScale) : bounds.width,
                fontSize: 8 * renderScale,
                fill: shape.stroke || '#000000',
                backgroundColor: '#FFFFFF',
                textAlign: 'left',
                left: bounds.left,
                top: bounds.top - (3 * renderScale),
                originY: 'bottom'
              });
              (tempFabric as any).add(text);
            }
          }
          (tempFabric as any).renderAll();
          tempCtx.drawImage((tempFabric as any).getElement(), 0, 0);
        }
        const imgData = (tempCanvas as any).toDataURL('image/jpeg', 0.9);
        const pdfPageSize = page.getViewport({ scale: 1 });
        const orientation = pdfPageSize.width > pdfPageSize.height ? 'l' : 'p';
        if (i > 1) { newPdf.addPage([pdfPageSize.width, pdfPageSize.height], orientation as any); }
        else { newPdf.internal.pageSize.setWidth(pdfPageSize.width); newPdf.internal.pageSize.setHeight(pdfPageSize.height); }
        newPdf.addImage(imgData, 'JPEG', 0, 0, newPdf.internal.pageSize.getWidth(), newPdf.internal.pageSize.getHeight());
      }
      newPdf.save('VikCraftEditor-Annotated.pdf');
    } catch (error) {
      console.error("Failed to generate annotated PDF:", error);
    } finally {
      this.loader.style.display = 'none';
    }
  }
  onPrevPage() { if (this.currentPage > 1) this.renderPage(--this.currentPage); }
  onNextPage() { if (this.currentPage < this.pdfDoc.numPages) this.renderPage(++this.currentPage); }
  goToPage() {
    if(!this.pageInput) return;
    const num = parseInt(this.pageInput.value, 10);
    if (num >= 1 && num <= this.pdfDoc.numPages) this.renderPage(num);
  }
  onZoom(level: 'in'|'out'|'fit') {
    if (!this.pdfDoc) return;
    if (level === 'in') this.zoomScale += 0.25;
    else if (level === 'out') this.zoomScale = Math.max(0.25, this.zoomScale - 0.25);
    else if (level === 'fit') {
      this.pdfDoc.getPage(this.currentPage).then((page: any) => {
        const container = this.container.querySelector('#vc-pdf-viewer-main') as HTMLElement;
        if (container) this.zoomScale = (container.clientWidth - 40) / page.getViewport({ scale: 1 }).width;
        this.renderPage(this.currentPage);
      });
      return;
    }
    this.renderPage(this.currentPage);
  }
}
